<?php

$con = mysqli_connect('localhost','root','','cric11') or mysqli_error($con);
function match_list(){
 $api_url  = "http://cricapi.com/api/matches?apikey=ThMVp9ScvjXSWyZgiVXVY5808lk2";
//$api_url  = "https://cricapi.com/api/fantasySummary?apikey=ThMVp9ScvjXSWyZgiVXVY5808lk2&unique_id=1034809";

//  Initiate curl
$ch = curl_init();
// Disable SSL verification
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// Will return the response, if false it print the response
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// Set the url
curl_setopt($ch, CURLOPT_URL,$api_url);
// Execute
$result=curl_exec($ch);
// Closing
curl_close($ch);

// Will dump a json - you can save in variable and use the json
return json_decode($result,true);
}
/*

$match_list =match_list();
			
			foreach($match_list['matches'] as $match)
			{	
				$team1 =$match['team-1'];
				$team2 =$match['team-2'];
				extract($match);
				echo $sql ="INSERT IGNORE INTO matches(unique_id, date_time, team_1, team_2, match_type, toss_winner_team, winner_team, status) values('$unique_id', '$dateTimeGMT', '$team1', '$team2', '$type', '$toss_winner_team', '$winner_team', '$matchStarted')";
				mysqli_query($con,$sql) or mysqli_error($con);
				
				$sql2 ="update matches set status='$matchStarted' where unique_id ='$unique_id'";
				mysqli_query($con,$sql2) or mysqli_error($con);
				
			}
*/
?>
